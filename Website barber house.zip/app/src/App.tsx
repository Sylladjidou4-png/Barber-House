import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  Scissors, 
  Sparkles, 
  Droplets, 
  Package, 
  Phone, 
  MessageCircle, 
  MapPin, 
  Clock, 
  ChevronDown,
  Instagram,
  Menu,
  X
} from 'lucide-react';
import { useState } from 'react';

gsap.registerPlugin(ScrollTrigger);

// Services data
const services = [
  { name: 'Classic Cut', description: 'Clean lines, tailored finish.', price: '8,000 XOF', icon: Scissors },
  { name: 'Beard Sculpt', description: 'Shape, taper, and detail.', price: '5,000 XOF', icon: Sparkles },
  { name: 'Hot Towel Shave', description: 'Smooth, close, relaxing.', price: '6,000 XOF', icon: Droplets },
  { name: 'Grooming Package', description: 'Cut + shave + care.', price: '16,000 XOF', icon: Package },
];

// Pricing data
const pricing = [
  { name: 'Classic Cut', description: 'Precision haircut with styling', price: '8,000 XOF' },
  { name: 'Beard Sculpt', description: 'Expert beard shaping & trimming', price: '5,000 XOF' },
  { name: 'Hot Towel Shave', description: 'Traditional straight razor shave', price: '6,000 XOF' },
  { name: 'Grooming Package', description: 'Full service: cut, shave & care', price: '16,000 XOF' },
  { name: 'Kids Cut', description: 'Gentle cuts for young gentlemen', price: '5,000 XOF' },
  { name: 'Hair Design', description: 'Custom patterns & artistic fades', price: '3,000 XOF' },
];

// Team data
const team = [
  { name: 'Amadou K.', specialty: 'Master Barber', experience: '15+ years', image: '/barber-3.jpg' },
  { name: 'Ibrahim D.', specialty: 'Fade Specialist', experience: '8 years', image: '/barber-1.jpg' },
  { name: 'Moussa T.', specialty: 'Beard Expert', experience: '6 years', image: '/barber-2.jpg' },
];

// Testimonials
const testimonials = [
  { name: 'Karim B.', text: 'Best barbershop in Bamako. The attention to detail is unmatched.', rating: 5 },
  { name: 'Ousmane D.', text: 'Professional service, great atmosphere. My go-to place every week.', rating: 5 },
  { name: 'Abdoulaye S.', text: 'Finally found a barber who understands exactly what I want.', rating: 5 },
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [navVisible, setNavVisible] = useState(false);
  
  // Refs for sections
  const heroRef = useRef<HTMLDivElement>(null);
  const servicesRef = useRef<HTMLDivElement>(null);
  const manifestoRef = useRef<HTMLDivElement>(null);
  const teamRef = useRef<HTMLDivElement>(null);
  const bookingRef = useRef<HTMLDivElement>(null);
  const pricingRef = useRef<HTMLDivElement>(null);
  const locationRef = useRef<HTMLDivElement>(null);
  const testimonialsRef = useRef<HTMLDivElement>(null);
  const footerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Check for reduced motion preference
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    
    if (prefersReducedMotion) {
      return;
    }

    const ctx = gsap.context(() => {
      // Hero entrance animation (auto-play on load)
      const heroTl = gsap.timeline();
      heroTl
        .fromTo('.hero-wordmark', 
          { opacity: 0, y: 24, scale: 0.98 },
          { opacity: 1, y: 0, scale: 1, duration: 0.9, ease: 'power2.out' }
        )
        .fromTo('.hero-tagline',
          { opacity: 0, y: 14 },
          { opacity: 1, y: 0, duration: 0.6, ease: 'power2.out' },
          '-=0.4'
        )
        .fromTo('.hero-cta',
          { opacity: 0, y: 14 },
          { opacity: 1, y: 0, duration: 0.6, ease: 'power2.out' },
          '-=0.3'
        )
        .fromTo('.scroll-cue',
          { opacity: 0 },
          { opacity: 1, duration: 0.5 },
          '-=0.2'
        );

      // Hero scroll-driven exit
      ScrollTrigger.create({
        trigger: heroRef.current,
        start: 'top top',
        end: '+=130%',
        pin: true,
        scrub: 0.6,
        onUpdate: (self) => {
          const progress = self.progress;
          if (progress > 0.7) {
            const exitProgress = (progress - 0.7) / 0.3;
            gsap.set('.hero-wordmark', { 
              x: -18 * exitProgress + 'vw', 
              opacity: 1 - exitProgress * 0.75 
            });
            gsap.set('.hero-content-right', { 
              x: 18 * exitProgress + 'vw', 
              opacity: 1 - exitProgress * 0.8 
            });
          }
        }
      });

      // Services section
      ScrollTrigger.create({
        trigger: servicesRef.current,
        start: 'top top',
        end: '+=130%',
        pin: true,
        scrub: 0.6,
        onUpdate: (self) => {
          const progress = self.progress;
          
          // Entrance (0-30%)
          if (progress <= 0.3) {
            const entranceProgress = progress / 0.3;
            gsap.set('.services-headline', { 
              x: -40 * (1 - entranceProgress) + 'vw', 
              opacity: entranceProgress 
            });
            gsap.set('.services-grid', { 
              x: 50 * (1 - entranceProgress) + 'vw', 
              opacity: entranceProgress,
              scale: 0.96 + 0.04 * entranceProgress
            });
          }
          // Exit (70-100%)
          else if (progress > 0.7) {
            const exitProgress = (progress - 0.7) / 0.3;
            gsap.set('.services-headline', { 
              x: -18 * exitProgress + 'vw', 
              opacity: 1 - exitProgress * 0.75 
            });
            gsap.set('.services-grid', { 
              x: 18 * exitProgress + 'vw', 
              opacity: 1 - exitProgress * 0.75 
            });
          }
        }
      });

      // Manifesto section
      ScrollTrigger.create({
        trigger: manifestoRef.current,
        start: 'top top',
        end: '+=120%',
        pin: true,
        scrub: 0.6,
        onUpdate: (self) => {
          const progress = self.progress;
          
          if (progress <= 0.3) {
            const entranceProgress = progress / 0.3;
            gsap.set('.manifesto-line-1', { 
              x: -60 * (1 - entranceProgress) + 'vw', 
              opacity: entranceProgress 
            });
            gsap.set('.manifesto-line-2', { 
              x: -60 * (1 - Math.max(0, (entranceProgress - 0.2) / 0.8)) + 'vw', 
              opacity: Math.max(0, (entranceProgress - 0.2) / 0.8)
            });
            gsap.set('.manifesto-body', { 
              y: 10 * (1 - entranceProgress) + 'vh', 
              opacity: entranceProgress 
            });
          }
          else if (progress > 0.7) {
            const exitProgress = (progress - 0.7) / 0.3;
            gsap.set('.manifesto-text', { 
              x: 18 * exitProgress + 'vw', 
              opacity: 1 - exitProgress * 0.75 
            });
          }
        }
      });

      // Team section
      ScrollTrigger.create({
        trigger: teamRef.current,
        start: 'top top',
        end: '+=140%',
        pin: true,
        scrub: 0.6,
        onUpdate: (self) => {
          const progress = self.progress;
          
          if (progress <= 0.3) {
            const entranceProgress = progress / 0.3;
            gsap.set('.team-label', { 
              y: -6 * (1 - entranceProgress) + 'vh', 
              opacity: entranceProgress 
            });
            gsap.set('.team-headline', { 
              scale: 0.92 + 0.08 * entranceProgress, 
              opacity: entranceProgress 
            });
            gsap.set('.team-body', { 
              x: -20 * (1 - Math.max(0, (entranceProgress - 0.25) / 0.75)) + 'vw', 
              opacity: Math.max(0, (entranceProgress - 0.25) / 0.75)
            });
            gsap.set('.team-cta', { 
              x: 20 * (1 - Math.max(0, (entranceProgress - 0.3) / 0.7)) + 'vw', 
              opacity: Math.max(0, (entranceProgress - 0.3) / 0.7)
            });
          }
          else if (progress > 0.7) {
            const exitProgress = (progress - 0.7) / 0.3;
            gsap.set('.team-headline', { 
              scale: 1 + 0.06 * exitProgress, 
              opacity: 1 - exitProgress * 0.75 
            });
          }
        }
      });

      // Booking section
      ScrollTrigger.create({
        trigger: bookingRef.current,
        start: 'top top',
        end: '+=150%',
        pin: true,
        scrub: 0.6,
        onUpdate: (self) => {
          const progress = self.progress;
          
          if (progress <= 0.3) {
            const entranceProgress = progress / 0.3;
            gsap.set('.booking-headline', { 
              x: -50 * (1 - entranceProgress) + 'vw', 
              opacity: entranceProgress 
            });
            gsap.set('.booking-body', { 
              y: 6 * (1 - Math.max(0, (entranceProgress - 0.25) / 0.75)) + 'vh', 
              opacity: Math.max(0, (entranceProgress - 0.25) / 0.75)
            });
            gsap.set('.booking-card', { 
              x: 50 * (1 - entranceProgress) + 'vw', 
              opacity: entranceProgress,
              scale: 0.98 + 0.02 * entranceProgress
            });
          }
          else if (progress > 0.7) {
            const exitProgress = (progress - 0.7) / 0.3;
            gsap.set('.booking-content', { 
              y: -8 * exitProgress + 'vh', 
              opacity: 1 - exitProgress * 0.75 
            });
          }
        }
      });

      // Flowing sections animations
      gsap.utils.toArray<HTMLElement>('.reveal-up').forEach((el) => {
        gsap.fromTo(el,
          { y: 40, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: el,
              start: 'top 80%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      });

      // Staggered card reveals
      gsap.utils.toArray<HTMLElement>('.stagger-cards').forEach((container) => {
        const cards = container.querySelectorAll('.stagger-card');
        gsap.fromTo(cards,
          { y: 30, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.5,
            stagger: 0.08,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: container,
              start: 'top 75%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      });

    });

    // Navigation visibility
    const handleScroll = () => {
      setNavVisible(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });

    return () => {
      ctx.revert();
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const scrollToSection = (ref: React.RefObject<HTMLDivElement | null>) => {
    ref.current?.scrollIntoView({ behavior: 'smooth' });
    setMenuOpen(false);
  };

  return (
    <div className="relative bg-[#05070A] min-h-screen">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        navVisible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-full'
      }`}>
        <div className="glass-strong mx-4 mt-4 rounded-full px-6 py-3">
          <div className="flex items-center justify-between max-w-7xl mx-auto">
            <span className="font-display text-xl text-white tracking-wider">BARBER HOUSE</span>
            <div className="hidden md:flex items-center gap-8">
              <button onClick={() => scrollToSection(servicesRef)} className="text-sm text-secondary-light hover:text-white transition-colors">Services</button>
              <button onClick={() => scrollToSection(teamRef)} className="text-sm text-secondary-light hover:text-white transition-colors">Team</button>
              <button onClick={() => scrollToSection(pricingRef)} className="text-sm text-secondary-light hover:text-white transition-colors">Pricing</button>
              <button onClick={() => scrollToSection(locationRef)} className="text-sm text-secondary-light hover:text-white transition-colors">Location</button>
            </div>
            <button 
              onClick={() => scrollToSection(bookingRef)}
              className="btn-primary py-2 px-5 text-xs"
            >
              Book
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Button */}
      <button 
        onClick={() => setMenuOpen(!menuOpen)}
        className="fixed top-6 right-6 z-[60] md:hidden glass p-3 rounded-full"
      >
        {menuOpen ? <X className="w-5 h-5 text-white" /> : <Menu className="w-5 h-5 text-white" />}
      </button>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="fixed inset-0 z-[55] bg-[#05070A]/95 backdrop-blur-xl flex flex-col items-center justify-center gap-8">
          <button onClick={() => scrollToSection(servicesRef)} className="text-2xl text-white font-display tracking-wider">Services</button>
          <button onClick={() => scrollToSection(teamRef)} className="text-2xl text-white font-display tracking-wider">Team</button>
          <button onClick={() => scrollToSection(pricingRef)} className="text-2xl text-white font-display tracking-wider">Pricing</button>
          <button onClick={() => scrollToSection(locationRef)} className="text-2xl text-white font-display tracking-wider">Location</button>
          <button onClick={() => scrollToSection(bookingRef)} className="btn-primary mt-4">Book Now</button>
        </div>
      )}

      {/* Section 1: Hero */}
      <section ref={heroRef} className="relative w-full h-screen overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="/hero-barbershop.jpg" 
            alt="Barbershop Interior" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 gradient-overlay" />
          <div className="ice-overlay" />
        </div>
        
        {/* Persistent elements */}
        <div className="absolute top-6 left-6 z-20">
          <span className="font-display text-lg text-white tracking-wider">BARBER HOUSE</span>
        </div>
        <div className="absolute top-6 right-6 z-20 hidden md:block">
          <button onClick={() => scrollToSection(bookingRef)} className="btn-glass py-2 px-5 text-xs">
            Book
          </button>
        </div>
        
        {/* Hero Content */}
        <div className="relative z-10 h-full flex flex-col items-center justify-center px-4">
          <h1 className="hero-wordmark font-display text-[clamp(64px,12vw,160px)] text-white text-center leading-none">
            BARBER HOUSE
          </h1>
          <div className="hero-content-right flex flex-col items-center">
            <p className="hero-tagline text-[clamp(16px,2.5vw,28px)] text-secondary-light mt-6 tracking-[0.2em] uppercase font-light">
              Precision. Style. Confidence.
            </p>
            <button 
              onClick={() => scrollToSection(bookingRef)}
              className="hero-cta btn-primary mt-10 ice-glow"
            >
              Book Appointment
            </button>
            <p className="hero-tagline font-mono text-xs text-secondary-light/60 mt-4">
              Bamako • By appointment
            </p>
          </div>
        </div>
        
        {/* Scroll cue */}
        <div className="scroll-cue absolute bottom-8 left-6 z-20 flex flex-col items-center gap-2">
          <span className="font-mono text-xs text-secondary-light/60 uppercase">Scroll</span>
          <ChevronDown className="w-4 h-4 text-secondary-light/60 animate-bounce" />
        </div>
        <div className="absolute bottom-8 right-6 z-20">
          <span className="font-mono text-xs text-secondary-light/60 uppercase">Bamako</span>
        </div>
      </section>

      {/* Section 2: Services */}
      <section ref={servicesRef} className="relative w-full h-screen overflow-hidden z-20">
        <div className="absolute inset-0">
          <img 
            src="/hero-barbershop.jpg" 
            alt="Barbershop" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-[#05070A]/72" />
          <div className="ice-overlay" />
        </div>
        
        <div className="relative z-10 h-full flex items-center px-[7vw]">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 w-full max-w-7xl mx-auto">
            {/* Left: Headline */}
            <div className="services-headline flex flex-col justify-center">
              <h2 className="font-display text-[clamp(48px,8vw,120px)] text-white leading-none">
                SERVICES
              </h2>
              <p className="text-secondary-light mt-6 max-w-[28vw] text-lg">
                Cuts, shaves, grooming—executed with precision.
              </p>
            </div>
            
            {/* Right: Glass Grid */}
            <div className="services-grid grid grid-cols-2 gap-4">
              {services.map((service, index) => (
                <div 
                  key={index}
                  className="glass-card p-6 flex flex-col justify-between min-h-[180px] ice-glow-hover transition-all duration-300 hover:scale-[1.02]"
                >
                  <div>
                    <service.icon className="w-6 h-6 text-accent-blue mb-4" />
                    <h3 className="text-white font-medium text-lg">{service.name}</h3>
                    <p className="text-secondary-light text-sm mt-2">{service.description}</p>
                  </div>
                  <div className="flex items-center justify-between mt-4">
                    <span className="font-mono text-xs text-accent-blue">{service.price}</span>
                    <button 
                      onClick={() => scrollToSection(bookingRef)}
                      className="text-xs text-white/60 hover:text-white transition-colors"
                    >
                      Book →
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Section 3: Manifesto */}
      <section ref={manifestoRef} className="relative w-full h-screen overflow-hidden z-30">
        <div className="absolute inset-0">
          <img 
            src="/manifesto-scene.jpg" 
            alt="Barber at work" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-[#05070A]/45" />
          <div className="ice-overlay" />
        </div>
        
        <div className="relative z-10 h-full flex flex-col justify-center px-[7vw]">
          <div className="manifesto-text max-w-4xl">
            <h2 className="manifesto-line-1 font-display text-[clamp(52px,10vw,140px)] text-white leading-[0.9]">
              MORE THAN
            </h2>
            <h2 className="manifesto-line-2 font-display text-[clamp(52px,10vw,140px)] text-white leading-[0.9]">
              A HAIRCUT
            </h2>
          </div>
          
          <div className="manifesto-body absolute bottom-[10vh] left-[7vw] max-w-[34vw]">
            <p className="text-secondary-light text-lg leading-relaxed">
              We build consistency—sharp lines, clean fades, and the confidence that carries into your week.
            </p>
            <div className="flex gap-4 mt-6">
              <button 
                onClick={() => scrollToSection(bookingRef)}
                className="btn-primary"
              >
                Book Now
              </button>
              <button 
                onClick={() => scrollToSection(teamRef)}
                className="btn-glass"
              >
                Meet the Team
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Section 4: Team */}
      <section ref={teamRef} className="relative w-full h-screen overflow-hidden z-40">
        <div className="absolute inset-0">
          <img 
            src="/team-bw-detail.jpg" 
            alt="Barber craftsmanship" 
            className="w-full h-full object-cover grayscale"
          />
          <div className="absolute inset-0 bg-[#05070A]/55" />
          <div className="ice-overlay" />
        </div>
        
        <div className="relative z-10 h-full flex flex-col items-center justify-center px-[7vw]">
          <span className="team-label font-mono text-xs text-secondary-light uppercase tracking-[0.2em] absolute top-[6vh]">
            The Team
          </span>
          
          <h2 className="team-headline font-display text-[clamp(48px,10vw,140px)] text-white text-center leading-none mb-12">
            ATTENTION TO DETAIL
          </h2>
          
          {/* Team Cards */}
          <div className="team-body grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl w-full">
            {team.map((member, index) => (
              <div 
                key={index}
                className="glass-card p-6 flex flex-col items-center text-center ice-glow-hover transition-all duration-300 hover:scale-[1.02]"
              >
                <div className="w-24 h-24 rounded-full overflow-hidden mb-4 border-2 border-accent-blue/30">
                  <img 
                    src={member.image} 
                    alt={member.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-white font-medium text-lg">{member.name}</h3>
                <p className="text-accent-blue text-sm mt-1">{member.specialty}</p>
                <p className="text-secondary-light text-xs mt-2">{member.experience}</p>
              </div>
            ))}
          </div>
          
          <button 
            onClick={() => scrollToSection(bookingRef)}
            className="team-cta btn-glass mt-12"
          >
            Book an Appointment
          </button>
        </div>
      </section>

      {/* Section 5: Booking */}
      <section ref={bookingRef} className="relative w-full h-screen overflow-hidden z-50">
        <div className="absolute inset-0">
          <img 
            src="/booking-interior.jpg" 
            alt="Modern barbershop" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-[#05070A]/40" />
          <div className="ice-overlay" />
        </div>
        
        <div className="booking-content relative z-10 h-full flex items-center px-[7vw]">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 w-full max-w-7xl mx-auto">
            {/* Left: Booking info */}
            <div className="flex flex-col justify-center">
              <h2 className="booking-headline font-display text-[clamp(40px,6vw,80px)] text-white leading-none">
                BOOK YOUR<br />APPOINTMENT
              </h2>
              <p className="booking-body text-secondary-light mt-6 text-lg max-w-[30vw]">
                Pick a time. We'll handle the details.
              </p>
              <div className="booking-body flex gap-4 mt-8">
                <a 
                  href="https://wa.me/22372211933"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary flex items-center gap-2"
                >
                  <MessageCircle className="w-4 h-4" />
                  Book on WhatsApp
                </a>
                <a 
                  href="tel:+22372211933"
                  className="btn-glass flex items-center gap-2"
                >
                  <Phone className="w-4 h-4" />
                  Call
                </a>
              </div>
            </div>
            
            {/* Right: Glass info card */}
            <div className="booking-card glass-strong p-8 rounded-3xl max-w-[28vw] ml-auto">
              <h3 className="font-display text-2xl text-white mb-6">Hours & Location</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-accent-blue" />
                  <div>
                    <p className="text-white text-sm">Mon–Sat: 9h–20h</p>
                    <p className="text-secondary-light text-xs">Sunday: Closed</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-accent-blue" />
                  <div>
                    <p className="text-white text-sm">Bamako</p>
                    <p className="text-secondary-light text-xs">Kalaban Coura ACI, en face de Waraba Saba</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-accent-blue" />
                  <p className="text-white text-sm">+223 72 21 19 33</p>
                </div>
              </div>
              <div className="mt-6 pt-6 border-t border-white/10">
                <p className="font-mono text-xs text-secondary-light uppercase tracking-wider">By appointment only</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Section 6: Pricing */}
      <section ref={pricingRef} className="relative bg-[#0B0F17] py-24 z-50">
        <div className="ice-overlay" />
        <div className="relative z-10 max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Left: Sticky info */}
            <div className="lg:sticky lg:top-[18vh] lg:self-start reveal-up">
              <h2 className="font-display text-[clamp(48px,6vw,80px)] text-white leading-none">
                PRICING
              </h2>
              <p className="text-secondary-light mt-4 text-lg">
                Straightforward prices. No surprises.
              </p>
              <button 
                onClick={() => scrollToSection(bookingRef)}
                className="btn-primary mt-6"
              >
                Request Appointment
              </button>
            </div>
            
            {/* Right: Pricing cards */}
            <div className="lg:col-span-2 stagger-cards space-y-4">
              {pricing.map((item, index) => (
                <div 
                  key={index}
                  className="stagger-card glass-card p-6 flex items-center justify-between ice-glow-hover transition-all duration-300 hover:scale-[1.01]"
                >
                  <div>
                    <h3 className="text-white font-medium text-lg">{item.name}</h3>
                    <p className="text-secondary-light text-sm mt-1">{item.description}</p>
                  </div>
                  <span className="font-mono text-accent-blue text-lg">{item.price}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Section 7: Location */}
      <section ref={locationRef} className="relative bg-[#05070A] py-24">
        <div className="ice-overlay" />
        <div className="relative z-10 max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left: Info card */}
            <div className="reveal-up glass-strong p-8 rounded-3xl">
              <h2 className="font-display text-4xl text-white mb-6">LOCATION</h2>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <MapPin className="w-6 h-6 text-accent-blue mt-1" />
                  <div>
                    <p className="text-white text-lg">Kalaban Coura ACI</p>
                    <p className="text-secondary-light">En face de Waraba Saba</p>
                    <p className="text-secondary-light">Bamako, Mali</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <Clock className="w-6 h-6 text-accent-blue mt-1" />
                  <div>
                    <p className="text-white">Monday – Saturday</p>
                    <p className="text-secondary-light">9:00 AM – 8:00 PM</p>
                    <p className="text-secondary-light/60 text-sm mt-1">Sunday: Closed</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <Phone className="w-6 h-6 text-accent-blue" />
                  <p className="text-white">+223 72 21 19 33</p>
                </div>
              </div>
              <a 
                href="https://maps.google.com/?q=Kalaban+Coura+ACI+Bamako"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-glass w-full mt-8 flex items-center justify-center gap-2"
              >
                <MapPin className="w-4 h-4" />
                Get Directions
              </a>
            </div>
            
            {/* Right: Map placeholder */}
            <div className="reveal-up glass-card rounded-3xl overflow-hidden min-h-[400px] flex items-center justify-center">
              <div className="text-center">
                <MapPin className="w-16 h-16 text-accent-blue/30 mx-auto mb-4" />
                <p className="text-secondary-light">Kalaban Coura ACI</p>
                <p className="text-white font-medium mt-2">Bamako, Mali</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Section 8: Testimonials */}
      <section ref={testimonialsRef} className="relative bg-[#0B0F17] py-24">
        <div className="ice-overlay" />
        <div className="relative z-10 max-w-7xl mx-auto px-6">
          <h2 className="reveal-up font-display text-[clamp(36px,5vw,64px)] text-white mb-12">
            WHAT CLIENTS SAY
          </h2>
          
          <div className="stagger-cards grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <div 
                key={index}
                className="stagger-card glass-card p-6"
              >
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Sparkles key={i} className="w-4 h-4 text-accent-blue" />
                  ))}
                </div>
                <p className="text-white text-lg leading-relaxed mb-4">
                  "{testimonial.text}"
                </p>
                <p className="font-mono text-xs text-secondary-light uppercase tracking-wider">
                  — {testimonial.name}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 9: Footer */}
      <footer ref={footerRef} className="relative bg-[#05070A] py-24">
        <div className="ice-overlay" />
        <div className="relative z-10 max-w-7xl mx-auto px-6 text-center">
          <h2 className="reveal-up font-display text-[clamp(48px,8vw,100px)] text-white leading-none mb-8">
            READY WHEN YOU ARE.
          </h2>
          
          <div className="reveal-up flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <a 
              href="https://wa.me/22372211933"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-5 h-5" />
              Book on WhatsApp
            </a>
            <a 
              href="tel:+22372211933"
              className="btn-glass flex items-center justify-center gap-2"
            >
              <Phone className="w-5 h-5" />
              Call
            </a>
          </div>
          
          <div className="reveal-up flex flex-wrap justify-center gap-8 mb-12">
            <a 
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-secondary-light hover:text-white transition-colors"
            >
              <Instagram className="w-5 h-5" />
              <span className="text-sm">Instagram</span>
            </a>
            <button className="text-secondary-light hover:text-white transition-colors text-sm">
              Privacy Policy
            </button>
            <button 
              onClick={() => scrollToSection(bookingRef)}
              className="text-secondary-light hover:text-white transition-colors text-sm"
            >
              Contact
            </button>
          </div>
          
          <div className="pt-8 border-t border-white/10">
            <p className="font-display text-2xl text-white tracking-wider mb-2">BARBER HOUSE</p>
            <p className="font-mono text-xs text-secondary-light/60">
              © 2026 Barber House. All rights reserved.
            </p>
          </div>
        </div>
      </footer>

      {/* Floating Booking Button */}
      <a 
        href="https://wa.me/22372211933"
        target="_blank"
        rel="noopener noreferrer"
        className={`fixed bottom-6 right-6 z-40 btn-primary rounded-full p-4 shadow-2xl transition-all duration-500 ${
          navVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
        }`}
      >
        <MessageCircle className="w-6 h-6" />
      </a>
    </div>
  );
}

export default App;
